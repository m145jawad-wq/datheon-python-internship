# 📈 Stock Portfolio Performance Tracker

A console-based Python utility that tracks your stock holdings, calculates portfolio value and percentage gain/loss for every position, and saves a summary report to a CSV file.

## ✨ Features

- 🧾 Enter ticker symbols, share quantities and buy prices
- 💼 Holdings stored in a Python dictionary
- 🔁 Buying the same stock again updates the position using the average buy price
- 💲 Looks up current prices from the S&P 500 ticker dataset (CSV), with built-in sample prices as a fallback
- ✍️ Asks for the current price manually if a ticker is not found anywhere
- 📊 Calculates invested capital, current market value, gain/loss and % change per holding
- 🖥️ Clean, formatted console report with ▲ / ▼ indicators and portfolio totals
- 💾 Saves results to `portfolio_summary.csv` using the built-in `csv` module
- ✅ Input validation for tickers, shares and prices

## 🛠️ Tech Stack

- Python 3
- Standard Library (`csv`, `os`, `datetime`)

## 🚀 How to Run

1. Clone the repository:
   ```bash
   git clone https://github.com/m145jawad-wq/stock-portfolio-tracker.git
   cd stock-portfolio-tracker
   ```
2. (Optional) Put the S&P 500 dataset in the same folder and name it `sp500_tickers.csv`.
   The program looks for a ticker column (`Symbol` / `Ticker`) and a price column (`Price` / `Close` / `Current Price`).
3. Run:
   ```bash
   python portfolio.py
   ```

## 🕹️ Sample Run

```
Enter stock ticker (or 'done' to finish): AAPL
  Number of shares: 10
  Buy price per share: $150
  Added AAPL: 10 shares @ $150.00
```

```
Ticker    Shares      Buy $      Now $      Invested         Value    Gain/Loss     Change
------------------------------------------------------------------------------------------
AAPL          15     156.67     227.50      2,350.00      3,412.50   +$1,062.50 ▲  +45.21%
TSLA           5     300.00     248.10      1,500.00      1,240.50     -$259.50 ▼  -17.30%
------------------------------------------------------------------------------------------
TOTAL                                       3,870.00      4,743.00     +$873.00    +22.56%
```

## 📄 Output File: `portfolio_summary.csv`

| Column | Meaning |
|---|---|
| Date | When the report was generated |
| Ticker | Stock symbol (last row is `TOTAL`) |
| Shares | Number of shares held |
| Buy Price / Current Price | Price per share |
| Invested | Shares × buy price |
| Current Value | Shares × current price |
| Gain/Loss / Gain/Loss % | Profit or loss in $ and % |

## 🧩 Code Structure

| Function | Purpose |
|---|---|
| `load_price_data()` | Reads prices from the CSV dataset |
| `get_current_price()` | Dataset → sample prices → manual entry |
| `add_holding()` | Collects one position into the portfolio dictionary |
| `calculate_portfolio()` | Computes invested, value, gain and % |
| `display_report()` | Prints the formatted console table |
| `save_summary()` | Writes `portfolio_summary.csv` |
| `main()` | Runs the full program |

## 📚 What I Learned

- Working with dictionaries to store structured data
- Reading and writing CSV files with the `csv` module
- Financial calculations (average cost, gain/loss %)
- Formatting clean console output and validating user input

## ⚠️ Disclaimer

Prices come from a static dataset or sample values, not live market data. This project is for learning purposes only and is not financial advice.

## 👤 Author

**Jawad** | [GitHub](https://github.com/m145jawad-wq)

Built as Task 2 of the Datheon Python Programming Internship.
