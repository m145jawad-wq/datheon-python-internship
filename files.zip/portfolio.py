#!/usr/bin/env python3
"""
Stock Portfolio Performance Tracker
-----------------------------------
- Enter stock tickers, buy prices and share quantities
- Calculates invested capital, current market value, and % gain/loss per holding
- Shows a formatted console report
- Saves the summary to 'portfolio_summary.csv' using the built-in csv module

Current prices are looked up from the S&P 500 ticker dataset (CSV) if it is
placed next to this script as 'sp500_tickers.csv'. If a ticker is not found,
a built-in sample price is used, and if that is missing too the user is asked
to type the current price manually.
"""

import csv
import os
from datetime import datetime

PRICES_FILE = "sp500_tickers.csv"
SUMMARY_FILE = "portfolio_summary.csv"

# Column names we accept in the dataset (case-insensitive)
SYMBOL_COLUMNS = ("symbol", "ticker")
PRICE_COLUMNS = ("price", "current price", "current_price", "close", "last", "last price", "adj close")

# Fallback sample prices (USD) so the program works without any dataset
DEFAULT_PRICES = {
    "AAPL": 227.50, "MSFT": 415.20, "GOOGL": 172.30, "AMZN": 186.40,
    "TSLA": 248.10, "META": 520.75, "NVDA": 128.60, "NFLX": 690.30,
    "JPM": 205.40, "V": 275.80, "KO": 63.20, "DIS": 98.90,
    "NKE": 78.50, "INTC": 22.40, "AMD": 160.25,
}


# ---------------------------------------------------------------- helpers
def to_float(text):
    """Convert text like '$1,234.50' to a float. Returns None if invalid."""
    try:
        return float(str(text).replace("$", "").replace(",", "").strip())
    except ValueError:
        return None


def load_price_data(filename=PRICES_FILE):
    """Read ticker prices from a CSV file. Returns {} if file or columns are missing."""
    prices = {}
    if not os.path.isfile(filename):
        return prices
    try:
        with open(filename, "r", newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            if not reader.fieldnames:
                return prices
            columns = {name.strip().lower(): name for name in reader.fieldnames}
            symbol_col = next((columns[c] for c in SYMBOL_COLUMNS if c in columns), None)
            price_col = next((columns[c] for c in PRICE_COLUMNS if c in columns), None)
            if not symbol_col or not price_col:
                return prices
            for row in reader:
                price = to_float(row.get(price_col, ""))
                symbol = (row.get(symbol_col) or "").strip().upper()
                if symbol and price is not None and price > 0:
                    prices[symbol] = price
    except OSError:
        pass
    return prices


def get_current_price(ticker, dataset_prices):
    """Find the current price: dataset -> built-in samples -> ask the user."""
    if ticker in dataset_prices:
        return dataset_prices[ticker]
    if ticker in DEFAULT_PRICES:
        return DEFAULT_PRICES[ticker]
    print(f"  Price for {ticker} not found in the dataset.")
    while True:
        price = to_float(input(f"  Enter current price for {ticker}: $"))
        if price is not None and price > 0:
            return price
        print("  Please enter a valid positive number.")


# ------------------------------------------------------------------ input
def read_positive_number(prompt, as_int=False):
    """Keep asking until the user enters a valid positive number."""
    while True:
        value = to_float(input(prompt))
        if value is None or value <= 0:
            print("  Please enter a number greater than 0.")
        elif as_int and value != int(value):
            print("  Please enter a whole number of shares.")
        else:
            return int(value) if as_int else value


def add_holding(portfolio):
    """Ask for one holding and store it in the portfolio dictionary.
    Returns False when the user types 'done'."""
    ticker = input("\nEnter stock ticker (or 'done' to finish): ").strip().upper()
    if ticker == "DONE":
        return False
    if not ticker or not ticker.replace(".", "").replace("-", "").isalnum():
        print("  Invalid ticker symbol. Try again (example: AAPL).")
        return True

    shares = read_positive_number("  Number of shares: ", as_int=True)
    buy_price = read_positive_number("  Buy price per share: $")

    if ticker in portfolio:
        # Buying the same stock again: combine and use the average buy price
        old = portfolio[ticker]
        total_shares = old["shares"] + shares
        avg_price = (old["shares"] * old["buy_price"] + shares * buy_price) / total_shares
        portfolio[ticker] = {"shares": total_shares, "buy_price": avg_price}
        print(f"  Updated {ticker}: {total_shares} shares @ avg ${avg_price:,.2f}")
    else:
        portfolio[ticker] = {"shares": shares, "buy_price": buy_price}
        print(f"  Added {ticker}: {shares} shares @ ${buy_price:,.2f}")
    return True


# ------------------------------------------------------------ calculations
def calculate_portfolio(portfolio, dataset_prices):
    """Return (rows, totals) with all invested/current/gain figures."""
    rows = []
    total_invested = 0.0
    total_value = 0.0

    for ticker, pos in portfolio.items():
        current_price = get_current_price(ticker, dataset_prices)
        invested = pos["shares"] * pos["buy_price"]
        value = pos["shares"] * current_price
        gain = value - invested
        gain_pct = (gain / invested) * 100

        rows.append({
            "ticker": ticker,
            "shares": pos["shares"],
            "buy_price": pos["buy_price"],
            "current_price": current_price,
            "invested": invested,
            "value": value,
            "gain": gain,
            "gain_pct": gain_pct,
        })
        total_invested += invested
        total_value += value

    total_gain = total_value - total_invested
    total_pct = (total_gain / total_invested) * 100 if total_invested else 0.0
    totals = {
        "invested": total_invested,
        "value": total_value,
        "gain": total_gain,
        "gain_pct": total_pct,
    }
    return rows, totals


# ----------------------------------------------------------------- output
def money(amount):
    """Format money with a sign for gains/losses, e.g. +$12.50 / -$3.00."""
    sign = "-" if amount < 0 else "+"
    return f"{sign}${abs(amount):,.2f}"


def display_report(rows, totals):
    """Print a formatted table of all holdings and the portfolio totals."""
    line = "=" * 90
    print("\n" + line)
    print("PORTFOLIO PERFORMANCE REPORT".center(90))
    print(line)
    print(f"{'Ticker':<8}{'Shares':>8}{'Buy $':>11}{'Now $':>11}"
          f"{'Invested':>14}{'Value':>14}{'Gain/Loss':>13}{'Change':>11}")
    print("-" * 90)

    for r in rows:
        arrow = "▲" if r["gain"] >= 0 else "▼"
        print(f"{r['ticker']:<8}{r['shares']:>8}{r['buy_price']:>11,.2f}{r['current_price']:>11,.2f}"
              f"{r['invested']:>14,.2f}{r['value']:>14,.2f}{money(r['gain']):>13}"
              f" {arrow}{r['gain_pct']:>+8.2f}%")

    print("-" * 90)
    print(f"{'TOTAL':<8}{'':>8}{'':>11}{'':>11}"
          f"{totals['invested']:>14,.2f}{totals['value']:>14,.2f}{money(totals['gain']):>13}"
          f"  {totals['gain_pct']:>+8.2f}%")
    print(line)

    if totals["gain"] > 0:
        print(f"Your portfolio is UP {totals['gain_pct']:.2f}% overall. Nice work!")
    elif totals["gain"] < 0:
        print(f"Your portfolio is DOWN {abs(totals['gain_pct']):.2f}% overall.")
    else:
        print("Your portfolio is exactly break-even.")


def save_summary(rows, totals, filename=SUMMARY_FILE):
    """Write the portfolio summary to a CSV file (one row per holding + TOTAL)."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    header = ["Date", "Ticker", "Shares", "Buy Price", "Current Price",
              "Invested", "Current Value", "Gain/Loss", "Gain/Loss %"]
    try:
        with open(filename, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(header)
            for r in rows:
                writer.writerow([timestamp, r["ticker"], r["shares"],
                                 f"{r['buy_price']:.2f}", f"{r['current_price']:.2f}",
                                 f"{r['invested']:.2f}", f"{r['value']:.2f}",
                                 f"{r['gain']:.2f}", f"{r['gain_pct']:.2f}"])
            writer.writerow([timestamp, "TOTAL", "", "", "",
                             f"{totals['invested']:.2f}", f"{totals['value']:.2f}",
                             f"{totals['gain']:.2f}", f"{totals['gain_pct']:.2f}"])
        print(f"\nSummary saved to '{filename}'")
    except OSError as error:
        print(f"\nCould not save the summary file: {error}")


# ------------------------------------------------------------------- main
def main():
    print("=" * 50)
    print("   STOCK PORTFOLIO PERFORMANCE TRACKER")
    print("=" * 50)

    dataset_prices = load_price_data()
    if dataset_prices:
        print(f"Loaded {len(dataset_prices)} prices from '{PRICES_FILE}'.")
    else:
        print(f"'{PRICES_FILE}' not found or unreadable. Using built-in sample prices.")
        print("Sample tickers: " + ", ".join(sorted(DEFAULT_PRICES)))

    portfolio = {}  # {ticker: {"shares": int, "buy_price": float}}
    while add_holding(portfolio):
        pass

    if not portfolio:
        print("\nNo holdings entered. Goodbye!")
        return

    rows, totals = calculate_portfolio(portfolio, dataset_prices)
    display_report(rows, totals)
    save_summary(rows, totals)


if __name__ == "__main__":
    main()
